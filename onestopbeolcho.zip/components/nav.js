// /components/nav.js
function updateNav(isLoggedIn, userRole) {
  console.log('updateNav 호출:', { isLoggedIn, userRole });

  // 네비게이션 요소 확인
  const navContainer = document.querySelector('.nav-container');
  const navMenu = navContainer.querySelector('.nav-menu');
  const authLinkUpper = navContainer.querySelector('#auth-link-upper');
  const profileTab = navMenu.querySelector('#profile-tab');
  const workerLink = navMenu.querySelector('#worker-link');
  const adminLink = navMenu.querySelector('#admin-link');

  if (!navContainer || !navMenu || !authLinkUpper || !profileTab) {
    console.error('nav.js: 필수 요소가 누락되었습니다.', { navContainer, navMenu, authLinkUpper, profileTab });
    return;
  }

  // 권한에 따른 메뉴 표시 여부
  if (workerLink) {
    if (!isLoggedIn) {
      workerLink.parentElement.style.display = 'none';
    } else if (isLoggedIn && userRole !== 'worker' && userRole !== 'admin') {
      workerLink.parentElement.style.display = 'none';
    } else {
      workerLink.parentElement.style.display = 'inline-block';
    }
  }

  if (adminLink) {
    if (!isLoggedIn || (isLoggedIn && userRole !== 'admin')) {
      adminLink.parentElement.style.display = 'none';
    } else {
      adminLink.parentElement.style.display = 'inline-block';
    }
  }

  // "마이페이지" 링크 표시 여부 및 클릭 이벤트
  if (profileTab) {
    if (isLoggedIn) {
      profileTab.parentElement.style.display = 'inline-block';
    } else {
      profileTab.parentElement.style.display = 'inline-block'; // 비로그인 상태에서도 표시
      profileTab.addEventListener('click', (e) => {
        if (!isLoggedIn) {
          e.preventDefault();
          window.location.href = '/login.html'; // 비로그인 상태에서 로그인 페이지로 유도
        }
      });
    }
  }

  // 로그아웃/회원가입 링크 설정
  if (isLoggedIn) {
    authLinkUpper.addEventListener('click', async (e) => {
      e.preventDefault();
      try {
        if (typeof firebase !== 'undefined' && firebase.auth) {
          await firebase.auth().signOut();
          window.location.replace('/login.html');
        } else {
          console.error('Firebase Auth가 로드되지 않았습니다.');
          alert('로그아웃을 처리할 수 없습니다. Firebase 초기화 오류.');
        }
      } catch (error) {
        console.error('로그아웃 오류:', error);
        alert('로그아웃에 실패했습니다: ' + error.message);
      }
    });
  } else {
    authLinkUpper.href = '/signup.html';
  }
}

function initializeNavWhenFirebaseReady(attempt = 0, maxAttempts = 100) {
  const navContainer = document.querySelector('.nav-container');
  if (!navContainer) {
    console.error('nav-container 요소를 찾을 수 없습니다.');
    return;
  }

  // 인증 상태 확인 중에는 로딩 표시
  const loadingDiv = navContainer.querySelector('.nav-loading');
  if (loadingDiv) {
    loadingDiv.style.display = 'block';
  }

  if (attempt >= maxAttempts) {
    console.error('Firebase SDK 로드 실패: 최대 재시도 횟수 초과. 기본 네비게이션 바 렌더링.');
    updateNav(false, null);
    if (loadingDiv) loadingDiv.style.display = 'none';
    return;
  }

  if (typeof firebase === 'undefined' || !firebase.auth || !firebase.firestore) {
    console.log(`Firebase SDK 로드 대기 중... (시도 ${attempt + 1}/${maxAttempts})`);
    setTimeout(() => initializeNavWhenFirebaseReady(attempt + 1, maxAttempts), 100);
    return;
  }

  firebase.auth().setPersistence(firebase.auth.Auth.Persistence.LOCAL)
    .then(() => {
      console.log('세션 지속성 설정 완료: LOCAL');
      if (!firebase.auth().currentUser) {
        console.log('현재 사용자 없음, onAuthStateChanged 대기');
      }
      firebase.auth().onAuthStateChanged(async user => {
        let isLoggedIn, userRole;

        if (user) {
          console.log('사용자 로그인 상태 감지:', user.uid, user.email, user.metadata);
          isLoggedIn = true;

          try {
            const userDoc = await firebase.firestore().collection('users').doc(user.uid).get();
            if (userDoc.exists) {
              const userData = userDoc.data();
              userRole = userData.role || null;
            } else {
              userRole = null;
            }
          } catch (error) {
            console.error('사용자 역할 로드 오류:', error);
            userRole = null;
          }
        } else {
          console.log('사용자 비로그인 상태 감지');
          isLoggedIn = false;
          userRole = null;
        }

        // 인증 상태 확인 후 네비게이션 업데이트
        updateNav(isLoggedIn, userRole);
        if (loadingDiv) loadingDiv.style.display = 'none';
      }, error => {
        console.error('onAuthStateChanged 오류:', error);
        updateNav(false, null);
        if (loadingDiv) loadingDiv.style.display = 'none';
      });
    })
    .catch(error => {
      console.error('세션 지속성 설정 오류:', error);
      updateNav(false, null);
      if (loadingDiv) loadingDiv.style.display = 'none';
    });
}

document.addEventListener('DOMContentLoaded', () => {
  console.log('nav.js 로드 완료, 초기 렌더링 대기');
  initializeNavWhenFirebaseReady();
});