/home/user/onestopbeolcho/.devbox/virtenv/python311/bin/venvShellHook.sh
echo 'Welcome to devbox!' > /dev/null