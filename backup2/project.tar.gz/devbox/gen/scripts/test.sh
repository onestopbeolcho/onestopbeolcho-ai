set -e

if [ -z "$__DEVBOX_INIT_HOOK_2837be6b7ee3cb163079cdea6cd2086df683d405b92115fb4251383d283763f2" ]; then
    . /home/user/onestopbeolcho/.devbox/gen/scripts/.hooks.sh
fi

echo "Error: no test specified" && exit 1
