import openai
import os
import requests
import beautifulsoup4
import pandas
import schedule